# Tallow Reach: code architecture

**Reading order for an AI assistant:** this file, then [HOW_TO_ADD.md](HOW_TO_ADD.md)
(step-by-step recipes), then the `README.md` in the folder you are about to edit,
then [CHANGELOG.md](CHANGELOG.md) (what earlier sessions changed: the newest entries in full,
plus a one-line index of every older entry). Open [CHANGELOG_ARCHIVE.md](CHANGELOG_ARCHIVE.md)
only when the index shows an older entry that matters to the task. See "Keeping the docs
scalable" at the end of this file.

## Running it

```
npm install          # once
npm run build        # writes game/tallow-reach.html (single file, works offline)
npm run watch        # rebuilds on every save
npm test             # unit tests: data and save layers, plus content checks
```

`game/tallow-reach.html` is **generated** from `src/`. Never edit it by hand. It only
changes when someone runs `npm run build`, so every change to `src/` should end with
a reminder to rebuild. It is self-contained (three.js is bundled in), so it still
runs when opened from disk.

## Layers

Dependencies only point downward. Lower layers never import higher ones.

```
main.js                 boot + frame loop
ui/                     HUD, outpost menus, pause overlay       (reads state, calls sim actions)
render/                 three.js scene, models, camera          (reads state, never changes game rules)
sim/                    gameplay rules: flight, combat, economy, contracts, lifecycle
state/                  runtime state, persistent profile, save storage
data/                   static tuning: ships, items, weapons, station, contract templates
core/                   audio synth, keyboard/mouse input
util/                   math helpers, event bus, seedable RNG
```

Sideways imports inside a layer are fine when they are one-directional (for example
`sim/session.js` uses `sim/world.js`). To connect two systems that should not know
about each other, use the event bus instead.

## Where things live

| You want to...                       | Edit                                           |
|--------------------------------------|------------------------------------------------|
| Add or rebalance a ship              | `data/ships.js`                                |
| Add a cargo type or change prices    | `data/items.js`                                |
| Tune the basic cannon                 | `data/modules.js` (`cannon_basic`: `dmg`, `rate`, `bspd`, `draw`) |
| Tune the mining beam                  | `data/modules.js` (`beam_basic`: `period`, `range`, `draw`)  |
| Tune the missile or the shop list     | `data/weapons.js`                              |
| Add or price a shop weapon           | `data/weapons.js` (`SHOP_WEAPONS`)             |
| Change base module costs             | `data/station.js`                              |
| Add a contract type                  | `data/contracts.js` (list, generator, wording), plus a listener in `sim/contracts.js` |
| Add a sector or change the warp order| `data/sectors.js`; see HOW_TO_ADD.md recipe 14 |
| Change the warp timing or its lockout | `WARP` in `data/sectors.js` (the look itself follows those numbers) |
| Change pirate behaviour              | `sim/ai.js`                                    |
| Change flight feel                   | `sim/player.js` (`flight`)                     |
| Rebind keys                          | `BINDINGS` in `core/input.js`                  |
| Add an outpost screen (tab)          | `ui/screens.js` (`TABS`, `SCREENS`, a HTML function) and `ui/menu.js` (`ACTIONS`) |
| Add a module                         | `data/modules.js` (`MODULES`, `STOCK_FIT`); see HOW_TO_ADD.md recipe 16 |
| Swap modules between ship and storage| `sim/fitting.js` (`fitModule`, `unequip`, `storedFor`); picker in `ui/screens.js`, actions in `ui/menu.js` |
| Change how a bay opens or closes    | `ui/picker.js` (one picker at a time, pure and tested) |
| Change how much a module or an ore takes up, or how big a hold or the station store is | module `vol` in `data/modules.js`, ore `ITEM_VOL` in `data/items.js`, hull `cargo` in `data/ships.js`, `STORAGE_PER_LEVEL` in `data/station.js` |
| Move things between the station and a ship, buy a module into storage | `sim/inventory.js` (`moveCargo`, `moveModule`, `buyModule`); the Inventory tab is `inventoryHtml()` in `ui/screens.js`, its buttons are `mv`/`invPrev`/`invNext` in `ui/menu.js` |
| Give a hull its own bays             | `data/outfitting.js` (`SHIP_LAYOUTS`)           |
| Change what power does in flight      | `sim/power.js` (`powerOf`, `hasPower`, `setDraw`, `updatePower`) and `state.power`; who draws what is `sim/drive.js` + `sim/player.js` (drive), `sim/shield.js` (shields) and `sim/weapons.js` (guns) |
| Change how a ship flies               | the thruster module in `data/modules.js`; `sim/drive.js` turns it into `state.drive` |
| Change what shields do in flight      | `sim/shield.js` (`shieldOf`, `refreshShield`, `updateShield`) and `state.shield`; the numbers are on the shield module |
| Change what the guns do in flight     | `sim/guns.js` (which guns are fitted, `state.guns`) and `sim/weapons.js` (`updatePrimary`); the numbers are on the `cannon_basic` module |
| Add or reorder outfitting bay groups | `data/outfitting.js` (`MODULE_GROUPS`)          |
| Add a paint bay to Appearance        | `data/outfitting.js` (`APPEARANCE_SLOTS`), drawn by `appearanceHtml()` in `ui/screens.js` |
| Change the ship in the Outfitting view| `render/shipviewer.js` (camera, lights, framing); `ui/outfitting.js` (page, input) |
| Change the pause menu                | `ui/pause.js`, styles under "Pause overlay" in `styles.css` |
| Change colours or layout of any UI   | `styles.css` (sections are labelled)           |
| Add a sound                          | `core/audio.js` (`tone`, `nz`, or a new graph) |
| Change what gets saved               | `state/profile.js` (bump `SAVE_VERSION`, add a migration) |
| Change the in-flight power readout   | `ui/hud.js` (the power block) and `#pw` in `src/index.html`, styles under "Flight HUD" |
| Add tests                            | `tests/` (`*.test.mjs`, run by `npm test`)     |

## File map

```
src/main.js            boot, action handling (lock, weapon, dock, pause), frame loop
src/index.html         page shell: HUD elements, outpost panel, hint text
src/styles.css         all styling, in labelled sections
src/data/              tuning numbers and content tables (ships, items, weapons, station, contracts, sectors, camera, outfitting bays and paint slots, modules)
src/util/              events.js (bus), rng.js (seedable random), math.js (vectors, helpers)
src/core/              audio.js (synth + mute), input.js (keys -> named actions)
src/state/             state.js (runtime), profile.js (saved data), storage.js (slots, codes)
src/sim/               player, power, drive, fitting, inventory, weapons, combat, ai, asteroids, targeting, economy, contracts, session, sectors, effects, world
src/render/            scene.js (including one group per sector), models.js, camera.js, warpfx.js, shipviewer.js (Outfitting)
src/ui/                hud.js, menu.js (button actions), screens.js (outpost HTML), outfitting.js (ship window), picker.js (open bay), pause.js, warpflash.js
tests/                 profile.test.mjs (saves, RNG), content.test.mjs (data completeness)
docs/                  this file, HOW_TO_ADD.md, AI_PROMPTS.md, HANDOFF.md, CHANGELOG.md (recent + index), CHANGELOG_ARCHIVE.md (older, full text)
```

Each `src/` folder also has its own short `README.md`.

## Conventions

- **Data tables use short keys.** Ships: `n` name, `d` description, `cargo`, `dmg`,
  `mine`, `sc`, `price`, `col` (Hull HP come from the fitted hull module). Items: `n`, `v`.
  Contracts: `n` count, `r` reward, `o` ore, `p` progress. Keep the short keys when adding entries.
- **Tuning numbers go in `src/data/`.** Constants private to one system (ranges, timers)
  may sit at the top of that file with a comment.
- **`matrixWorld` is last frame's transform.** three.js only refreshes it when the scene is
  drawn, so `object.localToWorld(v)` during the frame loop silently uses where the object was
  one frame ago — an error that grows with speed. This is what made the chase camera trail
  further the faster the ship flew. Build world points from `position` and `quaternion` by hand
  when the result matters (see `render/camera.js`).
- **Camera trail has one home: the `CAMERA` table in `data/camera.js`** (`base` 11, `fast` 17,
  `reverse` 10.5, with the pure helper `cameraTrail(vf, fwdTop, revTop)`). It is the only thing
  that changes the chase distance with speed; the camera's easing must never see the ship's
  travel, or speed leaks back in.
- **The boost tank is part of the drive too.** `data/modules.js` gives the thrusters
  `bmax`/`buse`/`bfill` (tank size, units a second out, units a second back); `sim/drive.js`
  carries them on `state.drive` and sizes `state.player.enMax`, and `sim/player.js` burns and
  refills `player.en`. The HUD prints `en / enMax` beside the bar. Nothing else knows the numbers.
- **Speed and turn have one home: the fitted thrusters.** `sim/drive.js` reads the thruster
  module and writes `state.drive = { spd, turn }`; `sim/player.js` and `render/camera.js` read
  that and nothing else. Hulls no longer carry `spd`/`turn` at all: do not add them back and do
  not hard-code a speed. Swap the module, or add a field to it.
- **No thruster fitted means a dead ship.** `driveOf()` returns `{ spd: 0, turn: 0 }` when the
  thruster bay is empty (there is no hull fallback, on purpose: the bays are what make the ship
  fly). `flight()` then holds the throttle at 0 and refuses boost as well as thrust, so holding
  W, Shift or the mouse does nothing at all, and pressing any of them raises the centre-screen
  warning "Equip thrusters to move" (`tryingToMove()` in `sim/player.js`, repeat-limited by
  `state.player.noDriveT`). The HUD prints "No thrusters fitted: press G to dock and fit one."
  and `launch()` says the same in the centre message. Test it with any hull
  plus an empty thruster bay (`hasDrive(state.drive)` is false). Docking range is 300 m and
  launch puts the ship at 200 m, so an immobile ship can always dock straight back.
- **Shields come from the shield module, not the hull.** `sim/shield.js` reads `sh` (Shield HP),
  `regen` (Shield HP a second) and `delay` (seconds without a hit) and writes `state.shield` plus
  `P.shMax`. Any hit stamps `P.last` (in `hurt()`), and the recharge stays off until that was
  `delay` seconds ago; then it runs at full `regen`. No shield module means `P.shMax` is 0 and
  every hit goes to the hull. Later shield types with special behaviour (recharging under fire)
  are extra fields read by `updateShield()` — nothing outside that file changes. Shields also cost
  power: a flat `draw` MJ/s (2 on the basic module) all the while they are up, reported through
  `setDraw("shield", ...)` so `state.power.draw` stays the whole ship's bill. When the ship cannot
  pay that (no plant, flat cells) they bleed away at `drain` Shield HP a second and stay at 0 until
  the power comes back.
- **Hull HP come from the hull module, not the hull.** `sim/hull.js` reads `hp` from the
  fitted hull module the same way shields read `sh` — `hull_basic` grants 10 Hull HP, and it
  is standard issue. No hull module fitted means the ship has no Hull HP at all: `P.hullMax`
  is 0, `P.hull` is 0, and the first hit that reaches the hull emits `player-dead` (see
  `hurt()`) — a one-shot kill, exactly like taking the shields off. The hull has no recharge and
  no power bill: damage is only ever repaired at the outpost, for credits. The fraction left is
  kept in `profile.hp[ship]`, stamped on every hull hit (`hurt()`) and on dock, so a fit change
  or a hangar visit keeps the damage taken — never a free repair, and taking the module off at
  the dock un-fits the ship without forgetting the fraction it had. Repair costs
  (`economy.repairCost`) read the fitted module's Hull HP, not a hull stat.
- **Guns come from the primary bays, not the hull.** A gun is a module in the `primary`
  group (`cannon_basic`: `dmg` a shot, `rate` shots a second per barrel, `bspd` bullet speed, `draw` MJ/s,
  and `barrels` for linked barrels fired side by side, default 1).
  `sim/guns.js` turns the fitted bays into `state.guns`, one entry per gun in bay order, and
  `updatePrimary()` in `sim/weapons.js` fires them all on left click, each on its own
  `1 / rate` cooldown, from its nose hardpoints (a linked pair — the basic cannon —
  fires from the two fixed hardpoints at ±1.8 m, one bolt per side, the pre-module
  layout; a lone barrel fires from its bay position, `-1.8 + 3.6 * i` metres across
  the nose). The bay
  index is the only difference between the two bays: the same module behaves the same in
  either one, and there is no separate key for either. The gun's damage is multiplied by the
  hull's `dmg` (1 on every hull — the hulls are identical apart from the hold for now), so
  the module figure is the number the game uses. While the trigger is held and the guns are firing they report
  `setDraw("guns", draw * guns fitted)`; `hasPower()` decides whether they may fire at all, the
  same rule the thrusters follow. `state.flight.gunCd` holds one cooldown per fitted gun and
  `state.flight.gunsOn` says whether they fired this frame.
- **The mining beam is a module too, not a weapon flag.** `beam_basic` lives in the `primary`
  group (`period` 4 s of continuous contact per ore before the hull's `mine` multiplier,
  `range` 340 m, `draw` 2 MJ/s), bought in the Shop for 900 cr — buying it puts the module in
  storage, from where it can be fitted in either primary bay like a gun (key 2 selects the
  beam slot; with no beam fitted that slot is the `Empty weapon slot`).
  `sim/guns.js`'s `beamsOf()` picks the fitted beams (a primary module with `period`, no
  `dmg`), and `state.beams` holds them; `updatePrimary()` only cuts with the beam slot
  selected, a rock in reach and the power to pay (`setDraw("beam", …)`, `hasPower()`,
  `state.power.use.beam`), it draws only while actually cutting, and a whole ore banks per
  `period` of continuous contact (1 ore per 4 s, `best.ore` depletes per ore, the rock
  disappears when dry). The hull's `mine` multiplier is 1 on every hull. **The moment contact stops, the progress toward the next ore is
  lost** — `state.flight.beamT` (contact time) tracks it; docking, launching, a fit change
  or a warp clear it too. A small bar with the percentage (`#bm` in the HUD, directly under
  the "left in rock" hint) shows the progress while the beam is cutting; it is hidden
  otherwise. Each completed ore plays a chime (`oreGained()` in `core/audio.js`). The beam
  is not a gun: `gunsOf()` never returns it, so the guns and the beam slot never both fire.
  The first fitted beam (lowest bay) acts if two are fitted. Saves that owned the old shop
  beam were given one `beam_basic` in storage in save version 8 (not auto-fitted).
- **The missile launcher is a module too — it replaced the old `wp.msl` flag.** `missile_basic`
  lives in the `secondary` group (`dmg` 8, `cap` 12, `cd` 4 s), bought in the Shop for
  1500 cr like the old launcher (the row still includes 8 missiles) — buying it puts the
  module in storage, fitted in the secondary bay like any other module. The missile itself is
  unchanged (`data/weapons.js`: `sp0` 140, `max` 480, `acc` 300, `life` 7 s, `turn` 5.5,
  lock 2.34 s in the dashed cone, 20° cone, 2500 m range, `unitPrice` 35 cr per missile in
  the Shop). `sim/guns.js`'s `missilesOf()` picks the fitted launchers (a secondary module
  with `dmg`), `state.missiles` holds them, `updateMissiles()` only locks and fires with one
  fitted, `F.missileCd` uses the module's `cd` instead of the old flat 0.9 s, and a fired
  missile carries its module's `dmg` (8) into the world so a mid-flight fit change cannot
  alter it. Damage is 8 per missile — it used to be 80. The restock row in the Outfitting services box (below the 3D viewer) shows when
  a launcher is fitted, capped by that launcher. Saves that owned the old launcher were given
  one `missile_basic` in storage in save version 9 (not auto-fitted); the whole `wp` object
  left the save.
- **The primary line and the equip toast use the equipped modules' own names.**
  `moduleListName()` in `sim/guns.js` builds them (`Basic cannons`, `Basic cannons x2` in a
  doubled bay, `Basic mining beam`, `A + B` for a mixed pair), so the HUD and the toast can
  never drift apart from what is actually fitted.
- **`FLIGHT` in `data/ships.js` still scales every ship at once**: `turn` multiplies the
  drive's turn rate, and `strafe` / `lift` / `reverse` are fractions of the drive's `spd`. The
  main drive and its 2x boost are the only directions that reach full speed.
- **Inventory: every place is measured in m³, and `sim/inventory.js` is the one home for it.** There
  are two kinds of place. The **station** keeps ore in `profile.store` and spare parts in
  `profile.modules`; its room is `STORAGE_PER_LEVEL` (250) times the Storage bay level. A **ship's
  hold** is `profile.holds[shipId] = { cargo, modules }`, every owned ship has its own, and its room
  is the hull's `cargo`. One unit of ore is 1 m³ (`ITEM_VOL`); a module's volume is its `vol`. A
  module fitted in a bay takes no space anywhere. Ore and parts share the same room. Purchases land
  in the station (`buyModule`, no limit on how many of one part you can own, only on room), the
  player moves things on demand in the Inventory tab (`moveCargo`, `moveModule`), and the Outfitting
  bays are fitted from the **station's** parts only. Mining and crate pickup write to the flown
  ship's hold through `cargoOf()`; nothing reads a single `profile.cargo` any more (a test guards
  that). A ship's cargo stays in that ship when you switch to another, and a ship that is lost takes
  its hold with it. Do not write `profile.holds`, `profile.store` or `profile.modules` outside
  `sim/inventory.js`, `sim/fitting.js` and `sim/economy.js`.
- **Fitting lives in one place.** `sim/fitting.js` is the only code that writes
  `profile.loadout` or `profile.modules`, and it refreshes ship power after every change.
  Anything else that changes a bay must go through it, or the ship keeps the old numbers.
- **Outpost actions** are functions in `ACTIONS` in `ui/menu.js`. A button carries
  `data-a="actionName"` and optionally `data-b="argument"`. After each click the panel
  re-renders and the game autosaves.
- **Economy and contract functions** change `state.profile` and may return a message
  string, which the panel shows as a green toast.
- **Screens are pure functions** that return an HTML string from the current state.
  They never change state.
- **Anything that accumulates must be multiplied by `dt`.** A constant added per frame
  (`camera.rotateZ(0.05)` every frame, say) silently depends on the frame rate: harmless on a
  60 Hz screen, a visible bug on a 240 Hz one. This bit the warp roll once. Use
  `x += rate * dt`, or steer toward a target with `1 - Math.exp(-k * dt)`.
- **The Outfitting ship has its own renderer.** The outpost panel is HTML sitting on top
  of the game canvas, so a view inside it needs its own canvas and WebGL context
  (`render/shipviewer.js`). The panel rebuilds its HTML on every click, which takes that
  canvas out of the page without destroying it; `ui/outfitting.js` puts the same canvas
  back into `#shipview` after each render. Do not create a renderer per render, and keep
  `id="shipview"` in `outfittingHtml`.
- **Sounds** are played with `tone()` / `nz()` from `core/audio.js` and respect mute
  automatically. UI sounds go through `uiSound()` and `hoverSound()`.
- **Text shown to the player** is written inline in the screen or action that shows it.
- **Save changes** follow the rules in "Save compatibility" below.

## Events

Systems talk through `util/events.js` instead of importing each other. The
current events and their payloads are listed at the top of that file. To react
to gameplay from a new feature, subscribe with `on(name, handler)`. For example:

```js
import { on } from "../util/events.js";
on("pirate-killed", () => { /* achievements, faction reputation, ... */ });
```

If you add an event, add it to the list at the top of `util/events.js` in the same change.

## State

- `state.profile` is the save: credits, ships, base, contracts and stats. It is written to disk on dock and on every menu action.
- Everything else in `state/state.js` is runtime. It is rebuilt when the game loads.
- Systems read `state.*` directly. There is no hidden global, so tests can build a state object and call a system.

## Replayability hooks

- `util/rng.js`: `random()` is the seedable random source. Call `setSeed(n)` and anything
  that uses `random()` or `R()` becomes reproducible. Today that covers the contract board
  and the audio noise buffers. See "Known gaps" for what still bypasses it.
- `data/contracts.js`: contract generators take a random source, so they can be seeded in the same way.

## Save compatibility

Storage keys (`tr1` for the autosave, `tr_s1`..`tr_s3` for slots) and the `TR1:` code prefix are unchanged from the prototype, so existing saves load. `sanitizeProfile` fills in defaults and clamps values, so older or partly corrupt saves still open.

When you change what is saved:

1. Add the field with a default in `newProfile()`.
2. Make `sanitizeProfile()` validate it (clamp numbers, drop unknown ids).
3. Raise `SAVE_VERSION` and add a line to the "Version history" comment.
4. If an old save needs converting rather than just defaulting, convert it in `sanitizeProfile()`.
5. Add a test in `tests/` that loads an old-shaped save.

## Known gaps (things to know before building on top)

These are real, current limits. None of them is a bug in play today.

- **Some randomness bypasses the seed.** `sim/ai.js`, `sim/combat.js` (loot drops) and
  `sim/asteroids.js` call `Math.random()` directly, so pirate waves, loot and some asteroid
  rolls ignore `setSeed`. Switching them to `random()` from `util/rng.js` makes them seedable
  with no change in unseeded play. Do this before building seeded sectors or daily challenges.
- **`sanitizeProfile` lists some things by name.** The three base modules (`store`, `hangar`,
  `refinery`) and the weapon flag (`msl`) are written out in `state/profile.js`. A new
  base module or weapon needs a line there too. `tests/content.test.mjs` fails if a base module is missing.
  (The `beam` flag left the save in version 8; the beam is a module.)
- **There is one enemy type.** Pirate numbers (Hull HP, speeds, ranges, fire rate) sit inside
  `sim/ai.js`. Before adding a second enemy, move them into a new `src/data/enemies.js` (see HOW_TO_ADD.md).
- **Every hull is the same ship apart from the hold today.** Thrusters set speed and turn,
  every hull ships with the same basic drive, and the hull's combat and mining multipliers
  are 1 everywhere. The only difference between hulls is the hold, measured in m³ (one
  cargo unit = 1 m³): Wasp 20 m³, Bulwark 30 m³, Prospector 70 m³. Ship-specific bonuses
  are meant to arrive later as hull attributes; hold size is the one stat being kept.
- **Only a handful of modules exist**: a powerplant, a power cell, basic thrusters, basic
  shields, the basic cannons, the basic mining beam, the basic missiles and the basic hull. They can be
  taken off and fitted again (`sim/fitting.js`, stored in `profile.modules`). The only
  modules a player can buy are the mining beam and the basic missiles (the Shop hands out
  `beam_basic` / `missile_basic`, as many as the station has room for), so the station's inventory
  otherwise only holds parts taken off a hull.
  Several things draw power (thrusters 2 MJ/s flying plus boost, shields, guns, the beam
  2 MJ/s cutting), so a basic plant out-produces the trickle and the cells stay near full
  unless the powerplant is removed.
- **Inventory limits.** Only the station's parts can be fitted in Outfitting: a module sitting in a
  ship's hold has to be moved back to the station first. Modules cannot be sold, there is no
  "move everything" button, and nothing yet uses a ship's hold of spare modules (fitting in the
  field is not possible). Cargo no longer travels with you between ships: it stays in the ship you
  left it in, and the Base screen's Store/Load/Sell buttons act on the ship being flown.
- **One active contract at a time** (`profile.mission`), and contract tiers are fixed at 1 to 3
  (`generateContract` in `sim/contracts.js`, wording in `ui/screens.js`).
- **`pirate-killed` carries no payload.** When enemy types arrive, emit `{ kind }` so listeners can tell them apart.
- **Muting is not saved.** Sound starts on every time the game opens.
- **The sector you are in is not saved.** `state.sector` is runtime only, so you always launch
  in Tallow Reach. Only Tallow Reach has content: Kestrel Hollow is empty, and the outpost,
  planet and rocks are hidden (not deleted) while you are away, so the field comes back as
  you left it.
- **A warp takes the controls for about two seconds, but not the momentum.** The throttle is
  released and the stick eases to neutral (`WARP_COAST` in `data/sectors.js`), so the ship
  coasts down and unwinds its turn; weapons are offline for the whole sequence. Enemies keep
  shooting at you while it charges. Making the ship invulnerable during a warp, or letting
  enemies lose interest, is a deliberate design decision that has not been made yet.
- **There is no star map screen yet.** M cycles through `SECTOR_IDS` in order and names the
  destination in a centre-screen message. A screen for choosing a destination is a new tab
  (recipe 7) once there are more than two sectors.
- **One sector's geography is written into the code.** The field belongs to `FIELD_SECTOR`
  (`sim/world.js`), and the outpost is always at the origin of the sector whose `st` flag is
  true. A second populated sector needs those two made per-sector.

## Keeping the docs scalable

The docs are read in full by a fresh assistant at the start of every chat, so they have to stay
a size that can be read in one go while still telling the whole story of the project.

- **`CHANGELOG.md` is the memory of the project, and it keeps its history.** It holds the newest
  entries in full and an "Older entries" index with one line per older entry (date and title).
  When it holds more than 15 full entries, move the oldest to the top of `CHANGELOG_ARCHIVE.md`
  until 10 remain, word for word, and add an index line for each one moved. Never delete or
  shorten history, only move it. Do this in the same change that adds a new entry.
- **Write entries so the index line is enough on its own.** The title says what changed and the
  first bullet says why. Put rules that must stay true in this file as well (the conventions
  above), not only in an entry, because entries get archived.
- **This file states how things are now, not how they got there.** When a change replaces an old
  rule, rewrite the rule here instead of adding a second one beside it; the story of the change
  belongs in the changelog. Remove "Known gaps" that have been closed.
- **Names, numbers and file lists that change often belong in one place.** Tuning numbers live in
  `src/data/` and the folder READMEs; avoid repeating them in several docs, because every copy
  has to be updated on every change.
- **If this file or `HOW_TO_ADD.md` passes about 40 KB**, split it by topic (for example
  `docs/CONVENTIONS.md`) and leave a short table of contents with links where the text was.
  Do the split as its own change, with no gameplay changes in it.
- **`HANDOFF.md` is a snapshot, not a log.** Rewrite it (do not append to it) when a chat ends:
  where the game is right now, the standing rules, and what to do next.
