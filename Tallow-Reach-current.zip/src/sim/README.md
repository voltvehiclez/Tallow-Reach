# src/sim: gameplay rules

Rules of the game. Reads and changes `state`, talks to other systems with events. Imports `data/`, `state/`, `util/`, `core/` (sound), and `render/` only to add or remove meshes.

| File | What it does |
|---|---|
| `player.js` | Ship setup (`setShip`), flight model and `hurt()` (shields absorb first, then the hull; the saved fraction `profile.hp[ship]` is stamped on every hull hit). A ship with no drive gets no thrust and no turn, and pressing a control warns "Equip thrusters to move". |
| `shield.js` | The ship's shields from the fitted module: `shieldOf` a loadout, `refreshShield` after a fit, ship change, load or dock, `updateShield` each frame (off while being hit, then `regen` a second after the `delay` lull). Also charges the ship a flat `shieldDraw` MJ/s for keeping them up, and bleeds them away when the ship cannot pay. |
| `power.js` | Ships' power budget: `powerOf` a loadout, `refreshPower`/`refillPower` after a fit change, `updatePower` each frame, and `hasPower` to ask whether the ship can pay for a demand. Writes `state.power` for the HUD; `draw` is set by the thrusters in `sim/player.js`, the shields in `sim/shield.js`, the guns and the beam in `sim/weapons.js`. |
| `hull.js` | The Hull HP the fitted hull module grants (`hull_basic`: `hp` 10) and `refreshHull()` after a fit change, a ship change, a save load or a dock. No module fitted means no Hull HP — any hit reaching the hull kills the ship. The saved fraction in `profile.hp[ship]` is applied; nothing here repairs. |
| `drive.js` | The ship's drive: `driveOf` a loadout, `refreshDrive` after a fit, ship change or undock, `hasDrive` to ask whether the ship can move at all. Writes `state.drive = { spd, turn, draw, boost, ignite, bmax, buse, bfill }` and sizes the boost tank (`player.enMax`), which the flight model and the chase camera read; `driveDraw` works out the per-second power the pilot is asking the thrusters for, and `ignite` is the one-off slug for lighting the boost. No thruster fitted gives 0 / 0: no thrust, turn or boost. |
| `fitting.js` | Moving modules between bays and storage: `fitModule`, `unequip`, `storedFor`, `fittedAt`. The only writer of `profile.loadout`/`profile.modules`; refreshes power, drive, shields and guns after every change. |
| `inventory.js` | Where things are kept and how full it is, in m³: the station (`profile.store` ore + `profile.modules` parts) and each ship's hold (`profile.holds[id]`). `holdOf`/`cargoOf` (a ship's hold; mining writes through `cargoOf()`), `loadOf`/`capacityOf`/`freeOf` (room), `moveCargo`/`moveModule` (between places), `buyModule` (a purchase into the station), `moduleStacks`. Pure: no 3D, so it is tested. |
| `guns.js` | The guns in the primary bays: `gunsOf` a loadout (pure, one `{i, id, dmg, rate, speed, draw, barrels}` per fitted gun) and `beamsOf` (the beam modules there, with `period`/`range`/`draw`), `refreshGuns` after a fit, ship change, load or dock, and `moduleListName` — the short name for a fitted list that the HUD and the equip toast share. Own module so `fitting.js`/`economy.js` can refresh the guns without importing the shooting code. |
| `weapons.js` | Firing the fitted guns on left click (each gun on its own 1/`rate` cooldown, one bolt per linked barrel per shot, drawing `draw` MJ/s while the trigger is held), the mining beam (per fitted `beam_basic` module: `period` seconds of continuous contact per ore, `range`, resetting the moment contact stops), missiles and lock-on (per the fitted `missile_basic` module: `dmg`, `cap`, `cd`; the missile's own flight and lock mechanics come from `data/weapons.js`). Re-exports `gunsOf`/`refreshGuns`. |
| `combat.js` | Bullets, hostile kills and loot drops, crates and pickups. |
| `ai.js` | Newbie Raiders: spawning, movement, shooting. Their numbers are the `RAIDER` constant at the top: name and 10 Hull HP, no shields. |
| `asteroids.js` | The asteroid field and ore types. |
| `targeting.js` | Target lock (F). |
| `economy.js` | Cargo, storage, selling, repairs, every purchase. Returns optional message text. |
| `contracts.js` | Offer board and event-driven progress tracking. |
| `session.js` | Launch, dock, die. Emits `launched`, `docked`, `died`. |
| `sectors.js` | Warping between sectors (M): swaps the scenery and the rock list. Emits `sector-changed`. |
| `effects.js` | Cosmetic explosions and exhaust. |
| `world.js` | Sector layout constants and `clearTransient()`. |

Rules:
- Use `emit`/`on` to connect systems that should not know each other.
- New rules that need numbers: put the numbers in `src/data/`.
- `docs/HOW_TO_ADD.md` recipes 3, 4, 6, 10, 11 touch this folder.
